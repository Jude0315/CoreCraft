// This service keeps HTTP requests separate from React page components.
// Keeping API logic here makes the frontend easier to understand and maintain.
import axios from "axios";

const API_URL =
  import.meta.env.VITE_API_URL ||
  "http://localhost:5001/api";

const API = axios.create({
  baseURL:
    API_URL,
});

API.interceptors.request.use(
  (config) => {
    const token =
      localStorage.getItem("token");

    if (token) {
      config.headers.Authorization =
        `Bearer ${token}`;
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export const UserApi = {
  getAll: () =>
    API.get("/auth/users"),

  getById: (id) =>
    API.get(`/auth/users/${id}`),

  create: (data) =>
    API.post(
      "/auth/users",
      data
    ),

  update: (id, data) =>
    API.put(
      `/auth/users/${id}`,
      data
    )
};

export const ProjectApi = {
  getAll: () =>
    API.get("/project"),

  getById: (id) =>
    API.get(`/project/${id}`),

  create: (data) =>
    API.post(
      "/project",
      data
    ),

  update: (id, data) =>
    API.put(
      `/project/${id}`,
      data
    ),

  remove: (id) =>
    API.delete(
      `/project/${id}`
    ),

  delete: (id) =>
    API.delete(
      `/project/${id}`
    )
};

export const TaskApi = {
  getAll: () =>
    API.get("/task"),

  getById: (id) =>
    API.get(`/task/${id}`),

  create: (data) =>
    API.post(
      "/task",
      data
    ),

  update: (id, data) =>
    API.put(
      `/task/${id}`,
      data
    )
};


export default API;
