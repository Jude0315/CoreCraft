# Project Management Tool

A modern web application for managing projects and tasks for small software teams.

Generated using **CoreCraft**.

## Technology Stack

- MongoDB
- Express.js
- React
- Node.js
- Mongoose
- JWT Authentication

## Application Roles

- Admin
- Project Manager
- Team Member

## Business Entities

- Project
  - name (String)
  - description (String)
  - startDate (Date)
  - deadline (Date)
  - status (String)
- Task
  - title (String)
  - description (String)
  - priority (String)
  - status (String)
  - dueDate (Date)
  - assignedTo (ObjectId)
  - project (ObjectId)

## Generated Pages

- Dashboard - /dashboard
- Projects - /projects
- Tasks - /tasks
- Login - /login
- Registration - /register

## API Modules

- User API: create, read, update
- Project API: create, read, update, delete
- Task API: create, read, update

## Generated Features

- projectManagement
- taskManagement
- userRoles
- taskAssignment
- taskTracking
- priorityManagement
- deadlineMonitoring
- progressTracking
- roleBasedDashboard
- userManagement
- darkCyanBlueUI

## Project Structure

```text
Client/
  src/
    Components/
    Context/
    Layouts/
    Pages/
    Routes/
    Services/
    Utils/

Server/
  Src/
    Config/
    Controllers/
    Middleware/
    Models/
    Routes/
    Utils/

README.md
```

## Authentication

The application includes JWT-based authentication and protected routes.

Role-based access rules are generated from the CoreCraft application specification.

## Backend Setup

```bash
cd Server
npm install
```

The generated `.env` file contains local development defaults, so you can run the backend immediately:

```bash
npm run dev
```

Default backend address:

```text
http://localhost:5001
```

## Frontend Setup

Open another terminal:

```bash
cd Client
npm install
npm run dev
```

Default frontend address:

```text
http://localhost:5173
```

## Generated Capabilities

CoreCraft may generate:

- database models
- REST API controllers
- API routes
- authentication
- role-based authorization
- CRUD interfaces
- relationship lookups
- dashboards
- navigation
- dynamic UI styling
- AI-designed authentication interfaces
- educational source-code comments

## Development Note

This project is generated as a development-ready MERN starter application.

Before production use, review security, environment configuration, validation, deployment settings, and application-specific requirements.

The included `.env` values are intended for local development only.

Change `JWT_SECRET` and database configuration before deployment.


---

Generated with CoreCraft.
