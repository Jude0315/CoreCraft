const express = require("express");

const {
  Register,
  Login,
  GetProfile,
  GetUsers,
  GetUserById,
  CreateUser,
  UpdateUser,
} = require("../Controllers/AuthController");

const AuthMiddleware = require(
  "../Middleware/AuthMiddleware"
);


const AllowRoles = require(
  "../Middleware/RoleMiddleware"
);


const Router = express.Router();

Router.post(
  "/register",
  Register
);

Router.post(
  "/login",
  Login
);

Router.get(
  "/profile",
  AuthMiddleware,
  GetProfile
);

Router.get(
  "/users",
  AuthMiddleware,
  AllowRoles(
    "Admin"
  ),
  GetUsers
);

Router.get(
  "/users/:id",
  AuthMiddleware,
  AllowRoles(
    "Admin"
  ),
  GetUserById
);


Router.post(
  "/users",
  AuthMiddleware,
  AllowRoles(
    "Admin"
  ),
  CreateUser
);


Router.put(
  "/users/:id",
  AuthMiddleware,
  AllowRoles(
    "Admin"
  ),
  UpdateUser
);



module.exports = Router;
