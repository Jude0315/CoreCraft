const express =
  require("express");

const {
  CreateProject,
  GetAllProjects,
  GetProjectById,
  UpdateProject,
  DeleteProject
} =
  require("../Controllers/ProjectController");

const AuthMiddleware =
  require("../Middleware/AuthMiddleware");

const AllowRoles =
  require("../Middleware/RoleMiddleware");


// This router defines the REST API endpoints for Project.
// Authentication runs first, followed by role-based authorization when required.
const Router =
  express.Router();


// The JWT middleware confirms that the request comes from a logged-in user.
// AllowRoles then checks whether that user's role can perform this operation.

Router.post(
  "/",
  AuthMiddleware, AllowRoles("Project Manager", "Admin"), CreateProject
);


// The JWT middleware confirms that the request comes from a logged-in user.
// AllowRoles then checks whether that user's role can perform this operation.

Router.get(
  "/",
  AuthMiddleware, AllowRoles("Project Manager", "Admin"), GetAllProjects
);

// The JWT middleware confirms that the request comes from a logged-in user.
// AllowRoles then checks whether that user's role can perform this operation.

Router.get(
  "/:id",
  AuthMiddleware, AllowRoles("Project Manager", "Admin"), GetProjectById
);


// The JWT middleware confirms that the request comes from a logged-in user.
// AllowRoles then checks whether that user's role can perform this operation.

Router.put(
  "/:id",
  AuthMiddleware, AllowRoles("Project Manager", "Admin"), UpdateProject
);


// The JWT middleware confirms that the request comes from a logged-in user.
// AllowRoles then checks whether that user's role can perform this operation.

Router.delete(
  "/:id",
  AuthMiddleware, AllowRoles("Admin"), DeleteProject
);


module.exports =
  Router;
