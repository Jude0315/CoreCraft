

const express =
  require("express");

const {
  GetTaskAssignedToLookup,
  GetTaskProjectLookup
} =
  require(
    "../Controllers/LookupController"
  );

const AuthMiddleware =
  require(
    "../Middleware/AuthMiddleware"
  );

const AllowRoles =
  require(
    "../Middleware/RoleMiddleware"
  );

const Router =
  express.Router();



Router.get(
  "/task/assignedTo",
  AuthMiddleware, AllowRoles("Admin", "Project Manager", "Team Member"),
  GetTaskAssignedToLookup
);


Router.get(
  "/task/project",
  AuthMiddleware, AllowRoles("Admin", "Project Manager", "Team Member"),
  GetTaskProjectLookup
);


module.exports =
  Router;
