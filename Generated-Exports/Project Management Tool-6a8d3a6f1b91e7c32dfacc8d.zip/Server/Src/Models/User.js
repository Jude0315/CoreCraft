const mongoose =
  require("mongoose");


const UserSchema =
  new mongoose.Schema(
    {
      name: {
        type: String,
        required: true,
        trim: true,
      },

      email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true,
      },

      password: {
        type: String,
        required: true,
      },

      role: {
        type: String,
        enum: ["Admin","Project Manager","Team Member"],
        default: "Admin",
      },
    },
    {
      timestamps: true,
    }
  );


module.exports =
  mongoose.model(
    "User",
    UserSchema
  );
