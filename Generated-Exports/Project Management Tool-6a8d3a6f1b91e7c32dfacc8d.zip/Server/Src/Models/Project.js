const mongoose = require("mongoose");

// Represents a project that encompasses multiple tasks.
// This model was generated dynamically by CoreCraft.
// Add domain-specific validation or business rules here if needed.

// This Mongoose schema defines the structure of each Project document stored in MongoDB.
// Each field below comes from the CoreCraft generation specification.
const ProjectSchema =
  new mongoose.Schema(
    {
  name: {
    type: String,
    required: true
  },

  description: {
    type: String
  },

  startDate: {
    type: Date,
    required: true
  },

  deadline: {
    type: Date,
    required: true
  },

  status: {
    type: String,
    required: true,
    enum: ["ongoing","completed","archived"],
    default: "ongoing"
  }
    },
    {
      timestamps: true,
    }
  );

module.exports =
  mongoose.model(
    "Project",
    ProjectSchema
  );
