const mongoose = require("mongoose");

// Represents a task that belongs to a project.
// This model was generated dynamically by CoreCraft.
// Add domain-specific validation or business rules here if needed.

// This Mongoose schema defines the structure of each Task document stored in MongoDB.
// Each field below comes from the CoreCraft generation specification.
const TaskSchema =
  new mongoose.Schema(
    {
  title: {
    type: String,
    required: true
  },

  description: {
    type: String
  },

  priority: {
    type: String,
    required: true,
    enum: ["low","normal","high"],
    default: "normal"
  },

  status: {
    type: String,
    required: true,
    enum: ["pending","in progress","completed"],
    default: "pending"
  },

  dueDate: {
    type: Date,
    required: true
  },

  // This field stores a reference to the User collection.
  // Mongoose can populate this reference so the frontend receives readable related data.
  assignedTo: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: "User"
  },

  // This field stores a reference to the Project collection.
  // Mongoose can populate this reference so the frontend receives readable related data.
  project: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: "Project"
  }
    },
    {
      timestamps: true,
    }
  );

module.exports =
  mongoose.model(
    "Task",
    TaskSchema
  );
