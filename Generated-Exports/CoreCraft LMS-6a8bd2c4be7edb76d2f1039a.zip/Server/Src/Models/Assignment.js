const mongoose = require("mongoose");

// Represents an assignment for a course.
// This model was generated dynamically by CoreCraft.
// Add domain-specific validation or business rules here if needed.

// This Mongoose schema defines the structure of each Assignment document stored in MongoDB.
// Each field below comes from the CoreCraft generation specification.
const AssignmentSchema =
  new mongoose.Schema(
    {
  title: {
    type: String,
    required: true
  },

  // This field stores a reference to the Course collection.
  // Mongoose can populate this reference so the frontend receives readable related data.
  course: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: "Course"
  },

  dueDate: {
    type: Date,
    required: true
  }
    },
    {
      timestamps: true,
    }
  );

module.exports =
  mongoose.model(
    "Assignment",
    AssignmentSchema
  );
