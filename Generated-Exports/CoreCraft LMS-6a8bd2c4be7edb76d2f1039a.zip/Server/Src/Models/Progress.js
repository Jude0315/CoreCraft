const mongoose = require("mongoose");

// Tracks student progress on assignments and courses.
// This model was generated dynamically by CoreCraft.
// Add domain-specific validation or business rules here if needed.

// This Mongoose schema defines the structure of each Progress document stored in MongoDB.
// Each field below comes from the CoreCraft generation specification.
const ProgressSchema =
  new mongoose.Schema(
    {
  // This field stores a reference to the User collection.
  // Mongoose can populate this reference so the frontend receives readable related data.
  student: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: "User"
  },

  // This field stores a reference to the Assignment collection.
  // Mongoose can populate this reference so the frontend receives readable related data.
  assignment: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: "Assignment"
  },

  status: {
    type: String,
    required: true,
    enum: ["complete","incomplete"],
    default: "incomplete"
  }
    },
    {
      timestamps: true,
    }
  );

module.exports =
  mongoose.model(
    "Progress",
    ProgressSchema
  );
