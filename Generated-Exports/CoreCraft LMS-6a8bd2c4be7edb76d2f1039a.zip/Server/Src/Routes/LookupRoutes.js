

const express =
  require("express");

const {
  GetCourseInstructorLookup,
  GetAssignmentCourseLookup,
  GetProgressStudentLookup,
  GetProgressAssignmentLookup
} =
  require(
    "../Controllers/LookupController"
  );

const AuthMiddleware =
  require(
    "../Middleware/AuthMiddleware"
  );

const AllowRoles =
  require(
    "../Middleware/RoleMiddleware"
  );

const Router =
  express.Router();



Router.get(
  "/course/instructor",
  AuthMiddleware, AllowRoles("instructor", "admin"),
  GetCourseInstructorLookup
);


Router.get(
  "/assignment/course",
  AuthMiddleware, AllowRoles("instructor", "admin"),
  GetAssignmentCourseLookup
);


Router.get(
  "/progress/student",
  AuthMiddleware,
  GetProgressStudentLookup
);


Router.get(
  "/progress/assignment",
  AuthMiddleware,
  GetProgressAssignmentLookup
);


module.exports =
  Router;
