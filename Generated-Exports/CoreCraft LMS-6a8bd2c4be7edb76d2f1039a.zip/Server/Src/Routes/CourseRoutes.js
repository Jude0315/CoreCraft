const express =
  require("express");

const {
  CreateCourse,
  GetAllCourses,
  GetCourseById,
  UpdateCourse,
  DeleteCourse
} =
  require("../Controllers/CourseController");

const AuthMiddleware =
  require("../Middleware/AuthMiddleware");

const AllowRoles =
  require("../Middleware/RoleMiddleware");


// This router defines the REST API endpoints for Course.
// Authentication runs first, followed by role-based authorization when required.
const Router =
  express.Router();


// The JWT middleware confirms that the request comes from a logged-in user.
// AllowRoles then checks whether that user's role can perform this operation.

Router.post(
  "/",
  AuthMiddleware, AllowRoles("instructor", "admin"), CreateCourse
);


// The JWT middleware confirms that the request comes from a logged-in user.
// AllowRoles then checks whether that user's role can perform this operation.

Router.get(
  "/",
  AuthMiddleware, AllowRoles("instructor", "admin"), GetAllCourses
);

// The JWT middleware confirms that the request comes from a logged-in user.
// AllowRoles then checks whether that user's role can perform this operation.

Router.get(
  "/:id",
  AuthMiddleware, AllowRoles("instructor", "admin"), GetCourseById
);


// The JWT middleware confirms that the request comes from a logged-in user.
// AllowRoles then checks whether that user's role can perform this operation.

Router.put(
  "/:id",
  AuthMiddleware, AllowRoles("instructor", "admin"), UpdateCourse
);


// The JWT middleware confirms that the request comes from a logged-in user.
// AllowRoles then checks whether that user's role can perform this operation.

Router.delete(
  "/:id",
  AuthMiddleware, AllowRoles("admin"), DeleteCourse
);


module.exports =
  Router;
