const Progress =
  require("../Models/Progress");


// Creates a new Progress record using data received from the request body.
const CreateProgress = async (req, res) => {
  try {
    const item =
      await Progress.create(
        req.body
      );

    return res
      .status(201)
      .json({
        message:
          "Progress created successfully",

        data: item,
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


// Retrieves Progress records from MongoDB and returns them to the frontend.
// Related reference fields are populated so users see readable values instead of database IDs.
const GetAllProgresss = async (req, res) => {
  try {
    const items =
      await Progress
        .find()
        .populate({
          path:
            "student",
          select:
            "name"
        })
        .populate({
          path:
            "assignment",
          select:
            "title"
        });

    return res
      .status(200)
      .json({
        count:
          items.length,

        data:
          items,
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


// Retrieves Progress records from MongoDB and returns them to the frontend.
// Related reference fields are populated so users see readable values instead of database IDs.
const GetProgressById = async (req, res) => {
  try {
    const item =
      await Progress
        .findById(
          req.params.id
        )
        .populate({
          path:
            "student",
          select:
            "name"
        })
        .populate({
          path:
            "assignment",
          select:
            "title"
        });

    if (!item) {
      return res
        .status(404)
        .json({
          message:
            "Progress not found",
        });
    }

    return res
      .status(200)
      .json({
        data:
          item,
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


module.exports = {
  CreateProgress,
  GetAllProgresss,
  GetProgressById
};
