

const User =
  require(
    "../Models/User"
  );

const Course =
  require(
    "../Models/Course"
  );

const Assignment =
  require(
    "../Models/Assignment"
  );



const GetCourseInstructorLookup =
  async (req, res) => {
    try {
      const filter =
        {
        ["role"]:
          "instructor"
      };

      const records =
        await User
          .find(filter)
          .select(
            "_id name"
          )
          .lean();

      const items =
        records.map(
          (record) => ({
            _id:
              record._id,

            label:
              [
                record["name"]
              ]
                .filter(
                  (value) =>
                    value !== undefined &&
                    value !== null &&
                    value !== ""
                )
                .map(
                  (value) =>
                    String(value)
                )
                .join(" - ") ||
              String(
                record._id
              ),
          })
        );

      return res.json(items);

    } catch (error) {

      return res.status(500).json({
        message:
          error.message,
      });

    }
  };


const GetAssignmentCourseLookup =
  async (req, res) => {
    try {
      const filter =
        {};

      const records =
        await Course
          .find(filter)
          .select(
            "_id title"
          )
          .lean();

      const items =
        records.map(
          (record) => ({
            _id:
              record._id,

            label:
              [
                record["title"]
              ]
                .filter(
                  (value) =>
                    value !== undefined &&
                    value !== null &&
                    value !== ""
                )
                .map(
                  (value) =>
                    String(value)
                )
                .join(" - ") ||
              String(
                record._id
              ),
          })
        );

      return res.json(items);

    } catch (error) {

      return res.status(500).json({
        message:
          error.message,
      });

    }
  };


const GetProgressStudentLookup =
  async (req, res) => {
    try {
      const filter =
        {
        ["role"]:
          "student"
      };

      const records =
        await User
          .find(filter)
          .select(
            "_id name"
          )
          .lean();

      const items =
        records.map(
          (record) => ({
            _id:
              record._id,

            label:
              [
                record["name"]
              ]
                .filter(
                  (value) =>
                    value !== undefined &&
                    value !== null &&
                    value !== ""
                )
                .map(
                  (value) =>
                    String(value)
                )
                .join(" - ") ||
              String(
                record._id
              ),
          })
        );

      return res.json(items);

    } catch (error) {

      return res.status(500).json({
        message:
          error.message,
      });

    }
  };


const GetProgressAssignmentLookup =
  async (req, res) => {
    try {
      const filter =
        {};

      const records =
        await Assignment
          .find(filter)
          .select(
            "_id title"
          )
          .lean();

      const items =
        records.map(
          (record) => ({
            _id:
              record._id,

            label:
              [
                record["title"]
              ]
                .filter(
                  (value) =>
                    value !== undefined &&
                    value !== null &&
                    value !== ""
                )
                .map(
                  (value) =>
                    String(value)
                )
                .join(" - ") ||
              String(
                record._id
              ),
          })
        );

      return res.json(items);

    } catch (error) {

      return res.status(500).json({
        message:
          error.message,
      });

    }
  };



module.exports = {
  GetCourseInstructorLookup,
  GetAssignmentCourseLookup,
  GetProgressStudentLookup,
  GetProgressAssignmentLookup
};
