const Course =
  require("../Models/Course");


// Creates a new Course record using data received from the request body.
const CreateCourse = async (req, res) => {
  try {
    const item =
      await Course.create(
        req.body
      );

    return res
      .status(201)
      .json({
        message:
          "Course created successfully",

        data: item,
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


// Retrieves Course records from MongoDB and returns them to the frontend.
// Related reference fields are populated so users see readable values instead of database IDs.
const GetAllCourses = async (req, res) => {
  try {
    const items =
      await Course
        .find()
        .populate({
          path:
            "instructor",
          select:
            "name"
        });

    return res
      .status(200)
      .json({
        count:
          items.length,

        data:
          items,
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


// Retrieves Course records from MongoDB and returns them to the frontend.
// Related reference fields are populated so users see readable values instead of database IDs.
const GetCourseById = async (req, res) => {
  try {
    const item =
      await Course
        .findById(
          req.params.id
        )
        .populate({
          path:
            "instructor",
          select:
            "name"
        });

    if (!item) {
      return res
        .status(404)
        .json({
          message:
            "Course not found",
        });
    }

    return res
      .status(200)
      .json({
        data:
          item,
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


// Updates an existing Course record using the ID provided in the request URL.
const UpdateCourse = async (req, res) => {
  try {
    const item =
      await Course.findByIdAndUpdate(
        req.params.id,
        req.body,
        {
          new: true,
          runValidators: true,
        }
      );

    if (!item) {
      return res
        .status(404)
        .json({
          message:
            "Course not found",
        });
    }

    return res
      .status(200)
      .json({
        message:
          "Course updated successfully",

        data:
          item,
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


// Deletes the selected Course record from MongoDB.
const DeleteCourse = async (req, res) => {
  try {
    const item =
      await Course.findByIdAndDelete(
        req.params.id
      );

    if (!item) {
      return res
        .status(404)
        .json({
          message:
            "Course not found",
        });
    }

    return res
      .status(200)
      .json({
        message:
          "Course deleted successfully",
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


module.exports = {
  CreateCourse,
  GetAllCourses,
  GetCourseById,
  UpdateCourse,
  DeleteCourse
};
