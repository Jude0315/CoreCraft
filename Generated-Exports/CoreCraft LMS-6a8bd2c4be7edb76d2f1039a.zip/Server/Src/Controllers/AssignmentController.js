const Assignment =
  require("../Models/Assignment");


// Creates a new Assignment record using data received from the request body.
const CreateAssignment = async (req, res) => {
  try {
    const item =
      await Assignment.create(
        req.body
      );

    return res
      .status(201)
      .json({
        message:
          "Assignment created successfully",

        data: item,
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


// Retrieves Assignment records from MongoDB and returns them to the frontend.
// Related reference fields are populated so users see readable values instead of database IDs.
const GetAllAssignments = async (req, res) => {
  try {
    const items =
      await Assignment
        .find()
        .populate({
          path:
            "course",
          select:
            "title"
        });

    return res
      .status(200)
      .json({
        count:
          items.length,

        data:
          items,
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


// Retrieves Assignment records from MongoDB and returns them to the frontend.
// Related reference fields are populated so users see readable values instead of database IDs.
const GetAssignmentById = async (req, res) => {
  try {
    const item =
      await Assignment
        .findById(
          req.params.id
        )
        .populate({
          path:
            "course",
          select:
            "title"
        });

    if (!item) {
      return res
        .status(404)
        .json({
          message:
            "Assignment not found",
        });
    }

    return res
      .status(200)
      .json({
        data:
          item,
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


// Updates an existing Assignment record using the ID provided in the request URL.
const UpdateAssignment = async (req, res) => {
  try {
    const item =
      await Assignment.findByIdAndUpdate(
        req.params.id,
        req.body,
        {
          new: true,
          runValidators: true,
        }
      );

    if (!item) {
      return res
        .status(404)
        .json({
          message:
            "Assignment not found",
        });
    }

    return res
      .status(200)
      .json({
        message:
          "Assignment updated successfully",

        data:
          item,
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


// Deletes the selected Assignment record from MongoDB.
const DeleteAssignment = async (req, res) => {
  try {
    const item =
      await Assignment.findByIdAndDelete(
        req.params.id
      );

    if (!item) {
      return res
        .status(404)
        .json({
          message:
            "Assignment not found",
        });
    }

    return res
      .status(200)
      .json({
        message:
          "Assignment deleted successfully",
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


module.exports = {
  CreateAssignment,
  GetAllAssignments,
  GetAssignmentById,
  UpdateAssignment,
  DeleteAssignment
};
