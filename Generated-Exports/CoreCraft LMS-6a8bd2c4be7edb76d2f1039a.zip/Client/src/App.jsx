import React from "react";

import {
  Routes,
  Route,
  Navigate,
} from "react-router-dom";


import Courses
  from "./Pages/Courses";
import Assignments
  from "./Pages/Assignments";
import ProgressTracking
  from "./Pages/ProgressTracking";
import Dashboard
  from "./Pages/Dashboard";


import ProtectedRoute
  from "./Routes/ProtectedRoute";

import AppLayout
  from "./Layouts/AppLayout";

import LoginPage
  from "./Pages/Login";

import RegisterPage
  from "./Pages/Register";



const App = () => {
  return (
    <Routes>


        <Route
          path="/"
          element={
            <Navigate
              to="/login"
              replace
            />
          }
        />



        <Route
          path="/login"
          element={
            <LoginPage />
          }
        />

        <Route
          path="/register"
          element={
            <RegisterPage />
          }
        />





        <Route
          element={
            <ProtectedRoute>

              <AppLayout />

            </ProtectedRoute>
          }
        >


          <Route
            path="/courses"
            element={
              <ProtectedRoute roles={["instructor","admin"]}>

                <Courses />

              </ProtectedRoute>
            }
          />

          <Route
            path="/assignments"
            element={
              <ProtectedRoute roles={["instructor","admin"]}>

                <Assignments />

              </ProtectedRoute>
            }
          />

          <Route
            path="/progress"
            element={
              <ProtectedRoute roles={["instructor","admin"]}>

                <ProgressTracking />

              </ProtectedRoute>
            }
          />

          <Route
            path="/dashboard"
            element={
              <ProtectedRoute roles={["admin","instructor"]}>

                <Dashboard />

              </ProtectedRoute>
            }
          />

        </Route>


        <Route
          path="*"
          element={
            <Navigate
              to="/"
              replace
            />
          }
        />

    </Routes>
  );
};


export default App;
