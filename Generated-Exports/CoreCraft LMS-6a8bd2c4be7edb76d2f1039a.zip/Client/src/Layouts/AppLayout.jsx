
import React from "react";

import {
  NavLink,
  Outlet,
  useNavigate,
} from "react-router-dom";

import {
  useAuth,
} from "../Context/AuthContext";


const navigationItems =
  [
  {
    "name": "Courses",
    "route": "/courses",
    "roles": [
      "instructor",
      "admin"
    ]
  },
  {
    "name": "Assignments",
    "route": "/assignments",
    "roles": [
      "instructor",
      "admin"
    ]
  },
  {
    "name": "Progress Tracking",
    "route": "/progress",
    "roles": [
      "instructor",
      "admin"
    ]
  },
  {
    "name": "Dashboard",
    "route": "/dashboard",
    "roles": [
      "admin",
      "instructor"
    ]
  }
];


const AppLayout = () => {

  const navigate =
    useNavigate();


  const {
    user,
    loading,
    Logout,
  } = useAuth();


  if (loading) {
    return (
      <div className="app-loading">
        Loading...
      </div>
    );
  }


  const role =
    user?.role || "";


  const visibleItems =
    navigationItems.filter(
      (item) =>
        item.roles.length === 0 ||
        item.roles.includes(
          role
        )
    );


  const HandleLogout = () => {
    Logout();

    navigate(
      "/login"
    );
  };


  return (
    <div
      className=
        "app-layout navigation-sidebar"
    >

      <header className="app-header">

        <div className="brand-block">

          <strong className="brand-name">
            CoreCraft LMS
          </strong>

        </div>


        


        <div className="header-actions">

          {role && (
            <span className="user-role">
              {role}
            </span>
          )}

          <button
            type="button"
            className="secondary-button"
            onClick={HandleLogout}
          >
            Logout
          </button>

        </div>

      </header>


      <div className="app-body">


        
        <aside className="app-sidebar">

          <nav className="side-navigation">

            {visibleItems.map(
              (item) => (
                <NavLink
                  key={item.route}
                  to={item.route}
                  className={({
                    isActive
                  }) =>
                    isActive
                      ? "nav-link active"
                      : "nav-link"
                  }
                >
                  {item.name}
                </NavLink>
              )
            )}

          </nav>

        </aside>



        <section className="app-content">

          <Outlet />

        </section>

      </div>

    </div>
  );
};


export default AppLayout;
