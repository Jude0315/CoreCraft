// This service keeps HTTP requests separate from React page components.
// Keeping API logic here makes the frontend easier to understand and maintain.
import axios from "axios";

const API_URL =
  import.meta.env.VITE_API_URL ||
  "http://localhost:5001/api";

const API = axios.create({
  baseURL:
    API_URL,
});

API.interceptors.request.use(
  (config) => {
    const token =
      localStorage.getItem("token");

    if (token) {
      config.headers.Authorization =
        `Bearer ${token}`;
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export const UserApi = {
  getAll: () =>
    API.get("/auth/users"),

  getById: (id) =>
    API.get(`/auth/users/${id}`),

  create: (data) =>
    API.post(
      "/auth/users",
      data
    )
};

export const CourseApi = {
  getAll: () =>
    API.get("/course"),

  getById: (id) =>
    API.get(`/course/${id}`),

  create: (data) =>
    API.post(
      "/course",
      data
    ),

  update: (id, data) =>
    API.put(
      `/course/${id}`,
      data
    ),

  remove: (id) =>
    API.delete(
      `/course/${id}`
    ),

  delete: (id) =>
    API.delete(
      `/course/${id}`
    )
};

export const AssignmentApi = {
  getAll: () =>
    API.get("/assignment"),

  getById: (id) =>
    API.get(`/assignment/${id}`),

  create: (data) =>
    API.post(
      "/assignment",
      data
    ),

  update: (id, data) =>
    API.put(
      `/assignment/${id}`,
      data
    ),

  remove: (id) =>
    API.delete(
      `/assignment/${id}`
    ),

  delete: (id) =>
    API.delete(
      `/assignment/${id}`
    )
};

export const ProgressApi = {
  getAll: () =>
    API.get("/progress"),

  getById: (id) =>
    API.get(`/progress/${id}`),

  create: (data) =>
    API.post(
      "/progress",
      data
    )
};


export default API;
