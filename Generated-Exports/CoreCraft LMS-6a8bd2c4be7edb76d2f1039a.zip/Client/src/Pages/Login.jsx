import React, {
  useState,
} from "react";

import {
  Link,
  useNavigate,
} from "react-router-dom";

import {
  useAuth,
} from "../Context/AuthContext";


const LoginPage = () => {
  const navigate =
    useNavigate();

  const {
    Login,
  } = useAuth();

  const [email, setEmail] =
    useState("");

  const [password, setPassword] =
    useState("");

  const [error, setError] =
    useState("");

  const [loading, setLoading] =
    useState(false);


  const HandleSubmit = async (
    event
  ) => {
    event.preventDefault();

    setError("");
    setLoading(true);

    try {
      const user = await Login(
        email,
        password
      );

      const roleLandingPages =
        {
  "instructor": "/courses",
  "admin": "/courses"
};

      const destination =
        roleLandingPages[user.role] ||
        "/courses";

      navigate(destination);
    } catch (error) {
      setError(
        error.response?.data?.message ||
        "Login failed"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-shell auth-position-center auth-align-center auth-background-solid auth-panel-bordered auth-decoration-none auth-brand-left auth-brand-align-center">

      <section className="auth-brand">

        <div className="auth-brand-content">

          <span className="eyebrow">
            Welcome to
          </span>

          <h1>
            CoreCraft LMS
          </h1>

          <p>
            A Learning Management System platform for students and teachers to manage courses, assignments, and progress tracking.
          </p>


        </div>

      </section>


      <section className="auth-panel">

        <form
          className="auth-card"
          onSubmit={HandleSubmit}
        >

          <h2>
            Welcome back
          </h2>

          <p>
            Enter your account details
            to continue.
          </p>


          {error && (
            <div className="form-error">
              {error}
            </div>
          )}


          <div className="form-group">

            <label>
              Email
            </label>

            <input
              type="email"
              value={email}
              onChange={(event) =>
                setEmail(
                  event.target.value
                )
              }
              required
            />

          </div>


          <div className="form-group">

            <label>
              Password
            </label>

            <input
              type="password"
              value={password}
              onChange={(event) =>
                setPassword(
                  event.target.value
                )
              }
              required
            />

          </div>


          <button
            className="primary-button"
            disabled={loading}
          >
            {loading
              ? "Signing in..."
              : "Sign in"}
          </button>


          <div className="auth-link">

            No account?{" "}

            <Link to="/register">
              Create one
            </Link>

          </div>

        </form>

      </section>

    </div>
  );
};

export default LoginPage;
