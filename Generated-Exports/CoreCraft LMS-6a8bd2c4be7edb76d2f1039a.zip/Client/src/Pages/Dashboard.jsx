import React, {
  useEffect,
  useState,
} from "react";


import {
  UserApi,
  CourseApi,
  AssignmentApi,
  ProgressApi
} from "../Services/Api";


const Dashboard = () => {

  const [
    userCount,
    setUserCount
  ] = useState(0);


  const [
    courseCount,
    setCourseCount
  ] = useState(0);


  const [
    assignmentCount,
    setAssignmentCount
  ] = useState(0);


  const [
    progressCount,
    setProgressCount
  ] = useState(0);


  const LoadDashboardData = async () => {

      try {
        const response =
          await UserApi.getAll();

        const payload =
          response.data;

        const records =
          Array.isArray(payload)
            ? payload
            : payload?.items ||
              payload?.data ||
              payload?.records ||
              [];

        const count =
          typeof payload?.count === "number"
            ? payload.count
            : Array.isArray(records)
              ? records.length
              : 0;

        setUserCount(
          count
        );
      } catch (error) {
        console.error(
          "Unable to load User dashboard data:",
          error
        );
      }


      try {
        const response =
          await CourseApi.getAll();

        const payload =
          response.data;

        const records =
          Array.isArray(payload)
            ? payload
            : payload?.items ||
              payload?.data ||
              payload?.records ||
              [];

        const count =
          typeof payload?.count === "number"
            ? payload.count
            : Array.isArray(records)
              ? records.length
              : 0;

        setCourseCount(
          count
        );
      } catch (error) {
        console.error(
          "Unable to load Course dashboard data:",
          error
        );
      }


      try {
        const response =
          await AssignmentApi.getAll();

        const payload =
          response.data;

        const records =
          Array.isArray(payload)
            ? payload
            : payload?.items ||
              payload?.data ||
              payload?.records ||
              [];

        const count =
          typeof payload?.count === "number"
            ? payload.count
            : Array.isArray(records)
              ? records.length
              : 0;

        setAssignmentCount(
          count
        );
      } catch (error) {
        console.error(
          "Unable to load Assignment dashboard data:",
          error
        );
      }


      try {
        const response =
          await ProgressApi.getAll();

        const payload =
          response.data;

        const records =
          Array.isArray(payload)
            ? payload
            : payload?.items ||
              payload?.data ||
              payload?.records ||
              [];

        const count =
          typeof payload?.count === "number"
            ? payload.count
            : Array.isArray(records)
              ? records.length
              : 0;

        setProgressCount(
          count
        );
      } catch (error) {
        console.error(
          "Unable to load Progress dashboard data:",
          error
        );
      }

  };


  useEffect(() => {
    LoadDashboardData();
  }, []);


  return (
    <main className="page-shell">

      <section className="page-header">

        <span className="eyebrow">
          CoreCraft LMS
        </span>

        <h1>
          Dashboard
        </h1>

        <p>
          Overview of LMS metrics and insights.
        </p>

      </section>


      <section className="dashboard-grid">

          <article className="stat-card">

            <span className="stat-label">
              User
            </span>

            <strong className="stat-value">
              {userCount}
            </strong>

          </article>

          <article className="stat-card">

            <span className="stat-label">
              Course
            </span>

            <strong className="stat-value">
              {courseCount}
            </strong>

          </article>

          <article className="stat-card">

            <span className="stat-label">
              Assignment
            </span>

            <strong className="stat-value">
              {assignmentCount}
            </strong>

          </article>

          <article className="stat-card">

            <span className="stat-label">
              Progress
            </span>

            <strong className="stat-value">
              {progressCount}
            </strong>

          </article>
      </section>

    </main>
  );
};


export default Dashboard;
