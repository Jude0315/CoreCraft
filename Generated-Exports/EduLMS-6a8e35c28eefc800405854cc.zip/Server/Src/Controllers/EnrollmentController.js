const Enrollment =
  require("../Models/Enrollment");


// Creates a new Enrollment record using data received from the request body.
const CreateEnrollment = async (req, res) => {
  try {
    const item =
      await Enrollment.create(
        req.body
      );

    return res
      .status(201)
      .json({
        message:
          "Enrollment created successfully",

        data: item,
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


// Retrieves Enrollment records from MongoDB and returns them to the frontend.
// Related reference fields are populated so users see readable values instead of database IDs.
const GetAllEnrollments = async (req, res) => {
  try {
    const items =
      await Enrollment
        .find()
        .populate({
          path:
            "student",
          select:
            "name"
        })
        .populate({
          path:
            "course",
          select:
            "title"
        });

    return res
      .status(200)
      .json({
        count:
          items.length,

        data:
          items,
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


// Retrieves Enrollment records from MongoDB and returns them to the frontend.
// Related reference fields are populated so users see readable values instead of database IDs.
const GetEnrollmentById = async (req, res) => {
  try {
    const item =
      await Enrollment
        .findById(
          req.params.id
        )
        .populate({
          path:
            "student",
          select:
            "name"
        })
        .populate({
          path:
            "course",
          select:
            "title"
        });

    if (!item) {
      return res
        .status(404)
        .json({
          message:
            "Enrollment not found",
        });
    }

    return res
      .status(200)
      .json({
        data:
          item,
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


// Deletes the selected Enrollment record from MongoDB.
const DeleteEnrollment = async (req, res) => {
  try {
    const item =
      await Enrollment.findByIdAndDelete(
        req.params.id
      );

    if (!item) {
      return res
        .status(404)
        .json({
          message:
            "Enrollment not found",
        });
    }

    return res
      .status(200)
      .json({
        message:
          "Enrollment deleted successfully",
      });
  } catch (error) {
    // Unexpected errors are returned with a useful message for the frontend.
    return res
      .status(500)
      .json({
        message:
          error.message,
      });
  }
};


module.exports = {
  CreateEnrollment,
  GetAllEnrollments,
  GetEnrollmentById,
  DeleteEnrollment
};
