

const express =
  require("express");

const {
  GetCourseInstructorLookup,
  GetEnrollmentStudentLookup,
  GetEnrollmentCourseLookup
} =
  require(
    "../Controllers/LookupController"
  );

const AuthMiddleware =
  require(
    "../Middleware/AuthMiddleware"
  );

const AllowRoles =
  require(
    "../Middleware/RoleMiddleware"
  );

const Router =
  express.Router();



Router.get(
  "/course/instructor",
  AuthMiddleware, AllowRoles("administrator", "instructor", "student"),
  GetCourseInstructorLookup
);


Router.get(
  "/enrollment/student",
  AuthMiddleware,
  GetEnrollmentStudentLookup
);


Router.get(
  "/enrollment/course",
  AuthMiddleware,
  GetEnrollmentCourseLookup
);


module.exports =
  Router;
