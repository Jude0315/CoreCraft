const express = require("express");

const {
  Register,
  Login,
  GetProfile,
  GetUsers,
  GetUserById,
  CreateUser,
  UpdateUser,
} = require("../Controllers/AuthController");

const AuthMiddleware = require(
  "../Middleware/AuthMiddleware"
);



const Router = express.Router();

Router.post(
  "/register",
  Register
);

Router.post(
  "/login",
  Login
);

Router.get(
  "/profile",
  AuthMiddleware,
  GetProfile
);

Router.get(
  "/users",
  AuthMiddleware,
  GetUsers
);

Router.get(
  "/users/:id",
  AuthMiddleware,
  GetUserById
);


Router.post(
  "/users",
  AuthMiddleware,
  CreateUser
);


Router.put(
  "/users/:id",
  AuthMiddleware,
  UpdateUser
);



module.exports = Router;
