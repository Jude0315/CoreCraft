const mongoose = require("mongoose");

// Links users to the courses they are enrolled in.
// This model was generated dynamically by CoreCraft.
// Add domain-specific validation or business rules here if needed.

// This Mongoose schema defines the structure of each Enrollment document stored in MongoDB.
// Each field below comes from the CoreCraft generation specification.
const EnrollmentSchema =
  new mongoose.Schema(
    {
  // This field stores a reference to the User collection.
  // Mongoose can populate this reference so the frontend receives readable related data.
  student: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: "User"
  },

  // This field stores a reference to the Course collection.
  // Mongoose can populate this reference so the frontend receives readable related data.
  course: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: "Course"
  }
    },
    {
      timestamps: true,
    }
  );

module.exports =
  mongoose.model(
    "Enrollment",
    EnrollmentSchema
  );
