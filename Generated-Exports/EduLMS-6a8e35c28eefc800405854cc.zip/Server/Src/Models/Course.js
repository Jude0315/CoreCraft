const mongoose = require("mongoose");

// Holds information about the courses available in the LMS.
// This model was generated dynamically by CoreCraft.
// Add domain-specific validation or business rules here if needed.

// This Mongoose schema defines the structure of each Course document stored in MongoDB.
// Each field below comes from the CoreCraft generation specification.
const CourseSchema =
  new mongoose.Schema(
    {
  title: {
    type: String,
    required: true
  },

  description: {
    type: String,
    required: true
  },

  // This field stores a reference to the User collection.
  // Mongoose can populate this reference so the frontend receives readable related data.
  instructor: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: "User"
  },

  category: {
    type: String,
    required: true,
    enum: ["Math","Science","Art","Technology"]
  },

  status: {
    type: String,
    required: true,
    enum: ["active","inactive"],
    default: "active"
  }
    },
    {
      timestamps: true,
    }
  );

module.exports =
  mongoose.model(
    "Course",
    CourseSchema
  );
