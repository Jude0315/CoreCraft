// This service keeps HTTP requests separate from React page components.
// Keeping API logic here makes the frontend easier to understand and maintain.
import axios from "axios";

const API_URL =
  import.meta.env.VITE_API_URL ||
  "http://localhost:5001/api";

const API = axios.create({
  baseURL:
    API_URL,
});

API.interceptors.request.use(
  (config) => {
    const token =
      localStorage.getItem("token");

    if (token) {
      config.headers.Authorization =
        `Bearer ${token}`;
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export const UserApi = {
  getAll: () =>
    API.get("/auth/users"),

  getById: (id) =>
    API.get(`/auth/users/${id}`),

  create: (data) =>
    API.post(
      "/auth/users",
      data
    ),

  update: (id, data) =>
    API.put(
      `/auth/users/${id}`,
      data
    )
};

export const CourseApi = {
  getAll: () =>
    API.get("/course"),

  getById: (id) =>
    API.get(`/course/${id}`),

  create: (data) =>
    API.post(
      "/course",
      data
    ),

  update: (id, data) =>
    API.put(
      `/course/${id}`,
      data
    ),

  remove: (id) =>
    API.delete(
      `/course/${id}`
    ),

  delete: (id) =>
    API.delete(
      `/course/${id}`
    )
};

export const EnrollmentApi = {
  getAll: () =>
    API.get("/enrollment"),

  getById: (id) =>
    API.get(`/enrollment/${id}`),

  create: (data) =>
    API.post(
      "/enrollment",
      data
    ),

  remove: (id) =>
    API.delete(
      `/enrollment/${id}`
    ),

  delete: (id) =>
    API.delete(
      `/enrollment/${id}`
    )
};


export default API;
