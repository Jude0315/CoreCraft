import React, {
  useEffect,
  useState,
} from "react";


import {
  useAuth,
} from "../Context/AuthContext";


import API, {
  CourseApi
} from "../Services/Api";


const Courses = () => {
  const [error, setError] =
    useState("");

  const [success, setSuccess] =
    useState("");


  // Stores the records loaded from the backend API.
  const [items, setItems] =
    useState([]);

  const [loading, setLoading] =
    useState(true);



  const [editingId, setEditingId] =
    useState(null);


  const initialForm = {
    title: "",
    description: "",
    instructor: "",
    category: "",
    status: "active"
  };

  // Stores the values currently entered in the create or edit form.
  const [form, setForm] =
    useState(
      initialForm
    );


  const {
    user,
  } = useAuth();



  const [
    instructorOptions,
    setInstructorOptions
  ] = useState([]);



  const pageActions =
    ["view","create","edit","delete"];

  const roleActions =
    [{"role":"administrator","actions":["view","create","edit","delete"]},{"role":"instructor","actions":["view","create","edit"]}];


  const CanPerformAction = (
    role,
    action,
    roleActions,
    fallbackActions
  ) => {
    if (
      !Array.isArray(roleActions) ||
      roleActions.length === 0
    ) {
      return (
        fallbackActions ||
        []
      )
        .map((item) =>
          String(item)
            .toLowerCase()
        )
        .includes(action);
    }

    const permission =
      roleActions.find(
        (entry) =>
          entry.role === role
      );

    return Boolean(
      permission?.actions
        ?.map((item) =>
          String(item)
            .toLowerCase()
        )
        .includes(action)
    );
  };


  // Checks whether the logged-in user's role can create records on this page.
  const canCreate =
    CanPerformAction(
      user?.role,
      "create",
      roleActions,
      pageActions
    );

  // Checks whether the logged-in user's role can edit records on this page.
  const canEdit =
    CanPerformAction(
      user?.role,
      "edit",
      roleActions,
      pageActions
    ) ||
    CanPerformAction(
      user?.role,
      "update",
      roleActions,
      pageActions
    );

  // Checks whether the logged-in user's role can delete records on this page.
  const canDelete =
    CanPerformAction(
      user?.role,
      "delete",
      roleActions,
      pageActions
    );




  const GetErrorMessage = (
    error,
    fallbackMessage
  ) => {
    return (
      error?.response?.data?.message ||
      error?.response?.data?.error ||
      error?.message ||
      fallbackMessage
    );
  };


  const GetSuccessMessage = (
    action
  ) => {
    switch (action) {
      case "create":
        return "Created successfully.";

      case "update":
        return "Updated successfully.";

      case "delete":
        return "Deleted successfully.";

      default:
        return "Operation completed successfully.";
    }
  };




  const formFields =
    [{"name":"title","type":"String","required":true,"unique":false,"defaultValue":null,"ref":"","referenceFilter":null,"displayFields":[],"enumValues":[],"description":"Stores the title of the course."},{"name":"description","type":"String","required":true,"unique":false,"defaultValue":null,"ref":"","referenceFilter":null,"displayFields":[],"enumValues":[],"description":"Stores a brief description of the course."},{"name":"instructor","type":"ObjectId","required":true,"unique":false,"defaultValue":null,"ref":"User","referenceFilter":{"field":"role","operator":"equals","value":"instructor"},"displayFields":["name"],"enumValues":[],"description":"References the instructor managing the course."},{"name":"category","type":"String","required":true,"unique":false,"defaultValue":null,"ref":"","referenceFilter":null,"displayFields":[],"enumValues":["Math","Science","Art","Technology"],"description":"Categorizes the course."},{"name":"status","type":"String","required":true,"unique":false,"defaultValue":"active","ref":"","referenceFilter":null,"displayFields":[],"enumValues":["active","inactive"],"description":"Indicates whether the course is active or inactive."}];


  const ValidateForm = (
    form,
    fields,
    editingId = null
  ) => {
    const errors = [];

    for (const field of fields) {
      const value =
        form[field.name];

      const isPasswordOnEdit =
        editingId &&
        field.name === "password";

      if (
        field.required &&
        !isPasswordOnEdit &&
        (
          value === "" ||
          value === null ||
          value === undefined
        )
      ) {
        errors.push(
          `${field.name} is required.`
        );

        continue;
      }

      if (
        field.type === "Number" &&
        value !== "" &&
        value !== null &&
        value !== undefined &&
        Number.isNaN(
          Number(value)
        )
      ) {
        errors.push(
          `${field.name} must be a valid number.`
        );
      }

      if (
        field.type === "Date" &&
        value
      ) {
        const date =
          new Date(value);

        if (
          Number.isNaN(
            date.getTime()
          )
        ) {
          errors.push(
            `${field.name} must be a valid date.`
          );
        }
      }
    }

    return errors;
  };




  /* -------------------------------------------------------
     Load records
     ------------------------------------------------------- */

  // Loads the existing records when the page opens.
  const LoadItems = async () => {
    try {
      setLoading(true);
      setError("");

      const response =
        await CourseApi.getAll();

      setItems(
        response.data.data || []
      );
    } catch (error) {
      console.error(error);

      setError(
        GetErrorMessage(
          error,
          "Unable to load records."
        )
      );
    } finally {
      setLoading(false);
    }
  };




  const LoadReferenceData = async () => {

    // Loads valid options for the instructor relationship field.
    // Any referenceFilter from the generated specification is enforced by the backend lookup API.
    try {
      const response =
        await API.get(
          "/lookups/course/instructor"
        );

      const items =
        Array.isArray(
          response.data
        )
          ? response.data
          : [];

      setInstructorOptions(
        items
      );
    } catch (error) {
      console.error(
        "Failed to load instructor lookup:",
        error
      );
    }
  };



  useEffect(() => {
    LoadItems();
    LoadReferenceData();
  }, []);


  /* -------------------------------------------------------
     Input change handler
     ------------------------------------------------------- */

  const HandleChange = (
    event
  ) => {
    const {
      name,
      value,
      type,
      checked,
    } = event.target;

    setForm(
      (previous) => ({
        ...previous,

        [name]:
          type === "checkbox"
            ? checked
            : value,
      })
    );
  };




  /* -------------------------------------------------------
     Reset form
     ------------------------------------------------------- */

  const ResetForm = () => {
    setForm(
      initialForm
    );

    setEditingId(null);
  };


  /* -------------------------------------------------------
     Clean payload before saving
     ------------------------------------------------------- */

  // Builds a clean request payload before sending form data to the backend.
  const BuildPayload = () => {
    const payload = {
      ...form,
    };

    Object.keys(payload).forEach((key) => {
      if (
        payload[key] === "" ||
        payload[key] === null ||
        payload[key] === undefined
      ) {
        delete payload[key];
      }
    });

    return payload;
  };


  /* -------------------------------------------------------
     Create / Update
     ------------------------------------------------------- */

  const HandleSubmit = async (
    event
  ) => {
    event.preventDefault();

    setError("");
    setSuccess("");

    const validationErrors =
      ValidateForm(
        form,
        formFields,
        editingId
      );

    if (
      validationErrors.length > 0
    ) {
      setError(
        validationErrors[0]
      );

      return;
    }


    if (
      editingId &&
      !canEdit
    ) {
      setError(
        "You do not have permission to update this record."
      );

      return;
    }

    if (
      !editingId &&
      !canCreate
    ) {
      setError(
        "You do not have permission to create this record."
      );

      return;
    }


    try {
      // Builds a clean request payload before sending form data to the backend.
      const payload =
        BuildPayload();


      if (editingId) {
        await CourseApi.update(
          editingId,
          payload
        );

        setSuccess(
          GetSuccessMessage(
            "update"
          )
        );
      } else {
        await CourseApi.create(
          payload
        );

        setSuccess(
          GetSuccessMessage(
            "create"
          )
        );
      }

      ResetForm();

      await LoadItems();
    } catch (error) {
      console.error(error);

      setError(
        GetErrorMessage(
          error,
          "Unable to save record."
        )
      );
    }
  };




  const NormalizeFormValue = (
    value,
    type
  ) => {
    if (
      value === null ||
      value === undefined
    ) {
      return "";
    }

    if (
      type === "ObjectId"
    ) {
      if (
        typeof value === "object"
      ) {
        return (
          value._id ||
          ""
        );
      }

      return value;
    }

    if (
      type === "Date"
    ) {
      const date =
        new Date(value);

      if (
        Number.isNaN(
          date.getTime()
        )
      ) {
        return "";
      }

      const offset =
        date.getTimezoneOffset();

      const localDate =
        new Date(
          date.getTime() -
          offset * 60 * 1000
        );

      return localDate
        .toISOString()
        .slice(
          0,
          16
        );
    }

    if (
      type === "Boolean"
    ) {
      return Boolean(value);
    }

    return value;
  };




  const HandleCancelEdit = () => {
    setEditingId(
      null
    );

    setForm(
      initialForm
    );
  };




  /* -------------------------------------------------------
     Edit
     ------------------------------------------------------- */

  // Loads the selected record into the form so the user can edit it.
  const HandleEdit = (
    item
  ) => {
    setEditingId(
      item._id
    );

    setForm({
      title:
        NormalizeFormValue(
          item.title,
          "String"
        ),
      description:
        NormalizeFormValue(
          item.description,
          "String"
        ),
      instructor:
        NormalizeFormValue(
          item.instructor,
          "ObjectId"
        ),
      category:
        NormalizeFormValue(
          item.category,
          "String"
        ),
      status:
        NormalizeFormValue(
          item.status,
          "String"
        )
    });

    setError("");
    setSuccess("");
  };




  /* -------------------------------------------------------
     Delete
     ------------------------------------------------------- */

  // Sends a delete request for the selected record and refreshes the list afterwards.
  const HandleDelete = async (
    id
  ) => {
    const confirmed =
      window.confirm(
        "Delete this Course?"
      );

    if (!confirmed) {
      return;
    }

    try {
      setError("");

      await CourseApi.remove(
        id
      );

      setSuccess(
        GetSuccessMessage(
          "delete"
        )
      );

      await LoadItems();
    } catch (error) {
      console.error(error);

      setError(
        GetErrorMessage(
          error,
          "Unable to delete record."
        )
      );
    }
  };




  /* -------------------------------------------------------
     Display helper
     ------------------------------------------------------- */

  const GetDisplayValue = (
    value,
    type,
    displayFields = []
  ) => {
    if (
      value === null ||
      value === undefined ||
      value === ""
    ) {
      return "-";
    }

    if (
      type === "ObjectId"
    ) {
      if (
        typeof value !== "object"
      ) {
        return String(value);
      }

      for (
        const field
        of displayFields
      ) {
        if (
          value[field] !==
            undefined &&
          value[field] !==
            null
        ) {
          const displayValue =
            value[field];

          const shouldFormatDate =
            String(field)
              .toLowerCase()
              .includes("date") ||
            String(field)
              .toLowerCase()
              .includes("time");

          if (shouldFormatDate) {
            const date =
              new Date(
                displayValue
              );

            if (
              !Number.isNaN(
                date.getTime()
              )
            ) {
              return date
                .toLocaleString();
            }
          }

          return String(
            displayValue
          );
        }
      }

      return (
        value.name ||
        value.title ||
        value._id ||
        "-"
      );
    }

    if (
      type === "Date"
    ) {
      const date =
        new Date(value);

      if (
        Number.isNaN(
          date.getTime()
        )
      ) {
        return String(value);
      }

      return date.toLocaleString();
    }

    if (
      type === "Boolean"
    ) {
      return value
        ? "Yes"
        : "No";
    }

    if (
      Array.isArray(value)
    ) {
      return value.join(", ");
    }

    return String(value);
  };



  return (
    <main className="page-shell">

      <section className="page-header">

        <span className="eyebrow">
          EduLMS
        </span>

        <h1>
          Courses
        </h1>

        <p>
          Allows users to manage and view courses.
        </p>

      </section>


      {error && (
        <div className="form-error">
          {error}
        </div>
      )}


      {success && (
        <div className="form-success">
          {success}
        </div>
      )}



      {(canCreate || (canEdit && editingId)) && (
        <section className="content-card">

          <div className="card-heading">
            <h2>
              {editingId
              ? "Edit Course"
              : "Create Course"}
            </h2>
          </div>


          <form
            className="entity-form"
            onSubmit={HandleSubmit}
          >


          <div className="form-group">

            <label>
              Title
            </label>

            <input
              type="text"
              id="title"
              name="title"
              value={
                form.title ||
                ""
              }
              onChange={
                HandleChange
              }
              required
            />

            <small>
              Stores the title of the course.
            </small>

          </div>


          <div className="form-group">

            <label>
              Description
            </label>

            <input
              type="text"
              id="description"
              name="description"
              value={
                form.description ||
                ""
              }
              onChange={
                HandleChange
              }
              required
            />

            <small>
              Stores a brief description of the course.
            </small>

          </div>


          <div className="form-group">

            <label htmlFor="instructor">
              Instructor
            </label>

            <select
              id="instructor"
              name="instructor"
              value={
                form.instructor ||
                ""
              }
              onChange={
                HandleChange
              }
              required
            >

              <option value="">
                Select Instructor
              </option>

              {instructorOptions.map(
                (item) => (
                  <option
                    key={item._id}
                    value={item._id}
                  >
                    {item.label}
                  </option>
                )
              )}

            </select>

            <small>
              References the instructor managing the course.
            </small>

          </div>


          <div className="form-group">

            <label htmlFor="category">
              Category
            </label>

            <select
              id="category"
              name="category"
              value={
                form.category ||
                ""
              }
              onChange={
                HandleChange
              }
              required
            >

              <option value="">
                Select Category
              </option>

              <option value="Math">
                Math
              </option>
              <option value="Science">
                Science
              </option>
              <option value="Art">
                Art
              </option>
              <option value="Technology">
                Technology
              </option>

            </select>

            <small>
              Categorizes the course.
            </small>

          </div>


          <div className="form-group">

            <label htmlFor="status">
              Status
            </label>

            <select
              id="status"
              name="status"
              value={
                form.status ||
                ""
              }
              onChange={
                HandleChange
              }
              required
            >

              <option value="">
                Select Status
              </option>

              <option value="active">
                active
              </option>
              <option value="inactive">
                inactive
              </option>

            </select>

            <small>
              Indicates whether the course is active or inactive.
            </small>

          </div>


            <div className="form-action-row">

              <button
                className="primary-button action-button"
                type="submit"
              >
                {editingId
                ? "Update Course"
                : "Create Course"}
              </button>



            {editingId && (
              <button
                type="button"
                className="secondary-button"
                onClick={HandleCancelEdit}
              >
                Cancel
              </button>
            )}


            </div>

          </form>

        </section>
      )}




      <section className="content-card module-section">

        <div className="card-heading">

          <h2>
            Courses
          </h2>

        </div>


        {loading ? (

          <p>
            Loading...
          </p>

        ) : items.length === 0 ? (

          <p>
            No records found.
          </p>

        ) : (

          <div className="table-wrapper">

            <table className="data-table">

              <thead>

                <tr>

              <th>Title</th>
              <th>Description</th>
              <th>Instructor</th>
              <th>Category</th>
              <th>Status</th>

                  {(canEdit || canDelete) && (
                    <th>
                      Actions
                    </th>
                  )}

                </tr>

              </thead>


              <tbody>

                {items.map(
                  (item) => (

                    <tr
                      key={item._id}
                    >

                <td>
                  {GetDisplayValue(
                    item.title,
                    "String",
                    []
                  )}
                </td>
                <td>
                  {GetDisplayValue(
                    item.description,
                    "String",
                    []
                  )}
                </td>
                <td>
                  {GetDisplayValue(
                    item.instructor,
                    "ObjectId",
                    ["name"]
                  )}
                </td>
                <td>
                  {GetDisplayValue(
                    item.category,
                    "String",
                    []
                  )}
                </td>
                <td>
                  {GetDisplayValue(
                    item.status,
                    "String",
                    []
                  )}
                </td>

                      {(canEdit || canDelete) && (
                        <td>

                          <div className="row-actions">

                            {canEdit && (
                              <button
                                className="secondary-button"
                                onClick={() =>
                                  HandleEdit(item)
                                }
                              >
                                Edit
                              </button>
                            )}

                            {canDelete && (
                              <button
                                className="danger-button"
                                onClick={() =>
                                  HandleDelete(
                                    item._id
                                  )
                                }
                              >
                                Delete
                              </button>
                            )}

                          </div>

                        </td>
                      )}

                    </tr>

                  )
                )}

              </tbody>

            </table>

          </div>

        )}

      </section>


    </main>
  );
};


export default Courses;
