import React, {
  useEffect,
  useState,
} from "react";


import {
  UserApi,
  CourseApi,
  EnrollmentApi
} from "../Services/Api";


const Dashboard = () => {

  const [
    userCount,
    setUserCount
  ] = useState(0);


  const [
    courseCount,
    setCourseCount
  ] = useState(0);


  const [
    enrollmentCount,
    setEnrollmentCount
  ] = useState(0);


  const LoadDashboardData = async () => {

      try {
        const response =
          await UserApi.getAll();

        const payload =
          response.data;

        const records =
          Array.isArray(payload)
            ? payload
            : payload?.items ||
              payload?.data ||
              payload?.records ||
              [];

        const count =
          typeof payload?.count === "number"
            ? payload.count
            : Array.isArray(records)
              ? records.length
              : 0;

        setUserCount(
          count
        );
      } catch (error) {
        console.error(
          "Unable to load User dashboard data:",
          error
        );
      }


      try {
        const response =
          await CourseApi.getAll();

        const payload =
          response.data;

        const records =
          Array.isArray(payload)
            ? payload
            : payload?.items ||
              payload?.data ||
              payload?.records ||
              [];

        const count =
          typeof payload?.count === "number"
            ? payload.count
            : Array.isArray(records)
              ? records.length
              : 0;

        setCourseCount(
          count
        );
      } catch (error) {
        console.error(
          "Unable to load Course dashboard data:",
          error
        );
      }


      try {
        const response =
          await EnrollmentApi.getAll();

        const payload =
          response.data;

        const records =
          Array.isArray(payload)
            ? payload
            : payload?.items ||
              payload?.data ||
              payload?.records ||
              [];

        const count =
          typeof payload?.count === "number"
            ? payload.count
            : Array.isArray(records)
              ? records.length
              : 0;

        setEnrollmentCount(
          count
        );
      } catch (error) {
        console.error(
          "Unable to load Enrollment dashboard data:",
          error
        );
      }

  };


  useEffect(() => {
    LoadDashboardData();
  }, []);


  return (
    <main className="page-shell">

      <section className="page-header">

        <span className="eyebrow">
          EduLMS
        </span>

        <h1>
          Dashboard
        </h1>

        <p>
          Provides an overview of user activity and enrolled courses.
        </p>

      </section>


      <section className="dashboard-grid">

          <article className="stat-card">

            <span className="stat-label">
              User
            </span>

            <strong className="stat-value">
              {userCount}
            </strong>

          </article>

          <article className="stat-card">

            <span className="stat-label">
              Course
            </span>

            <strong className="stat-value">
              {courseCount}
            </strong>

          </article>

          <article className="stat-card">

            <span className="stat-label">
              Enrollment
            </span>

            <strong className="stat-value">
              {enrollmentCount}
            </strong>

          </article>
      </section>

    </main>
  );
};


export default Dashboard;
