import React from "react";

import {
  Routes,
  Route,
  Navigate,
} from "react-router-dom";


import Dashboard
  from "./Pages/Dashboard";
import Courses
  from "./Pages/Courses";


import ProtectedRoute
  from "./Routes/ProtectedRoute";

import AppLayout
  from "./Layouts/AppLayout";

import LoginPage
  from "./Pages/Login";

import RegisterPage
  from "./Pages/Register";



const App = () => {
  return (
    <Routes>


        <Route
          path="/"
          element={
            <Navigate
              to="/login"
              replace
            />
          }
        />



        <Route
          path="/login"
          element={
            <LoginPage />
          }
        />

        <Route
          path="/register"
          element={
            <RegisterPage />
          }
        />





        <Route
          element={
            <ProtectedRoute>

              <AppLayout />

            </ProtectedRoute>
          }
        >


          <Route
            path="/dashboard"
            element={
              <ProtectedRoute roles={["administrator","instructor","student"]}>

                <Dashboard />

              </ProtectedRoute>
            }
          />

          <Route
            path="/courses"
            element={
              <ProtectedRoute roles={["administrator","instructor","student"]}>

                <Courses />

              </ProtectedRoute>
            }
          />

        </Route>


        <Route
          path="*"
          element={
            <Navigate
              to="/"
              replace
            />
          }
        />

    </Routes>
  );
};


export default App;
